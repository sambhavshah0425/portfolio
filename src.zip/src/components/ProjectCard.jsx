import { useRef } from 'react'
import ProjectVisual from './ProjectVisuals'

export default function ProjectCard({ project, index, onOpen, delay }) {
  const cardRef = useRef(null)

  function handleMouseMove(e) {
    const r = cardRef.current.getBoundingClientRect()
    const x = (e.clientX - r.left) / r.width - 0.5
    const y = (e.clientY - r.top) / r.height - 0.5
    cardRef.current.style.transform = `translateY(-4px) perspective(900px) rotateX(${y * -3}deg) rotateY(${x * 3}deg)`
  }
  function handleMouseLeave() { cardRef.current.style.transform = '' }

  return (
    <article
  ref={cardRef}
  className={`work-card reveal${delay ? ` reveal-delay-${delay}` : ''}`}
      onClick={() => onOpen(index)}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
    >
      <div className="work-visual">
        <ProjectVisual svgKey={project.svgKey} />
      </div>
      <div className="work-overlay">
        <span className="work-tag">{project.tag}</span>
        <div className="work-info">
          <div>
            <h3>{project.title}</h3>
            <div className="meta">{project.tech.join(' · ')}</div>
          </div>
          <div className="icon">↗</div>
        </div>
      </div>
    </article>
  )
}
