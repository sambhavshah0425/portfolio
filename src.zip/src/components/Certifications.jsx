import useReveal from '../hooks/useReveal'

const certs = [
  { icon: '☁️', title: 'AWS Cloud Fundamentals', sub: 'Amazon Web Services' },
  { icon: '🤖', title: 'AI & Machine Learning', sub: 'Deep Learning · NLP · CV' },
  { icon: '⚡', title: 'Full Stack Development', sub: 'MERN Stack · REST APIs' },
  { icon: '🔧', title: 'Data Engineering', sub: 'Pipelines · ETL · Analytics' }
]

export default function Certifications() {
  useReveal()

  return (
    <section id="certifications">
      <div className="container">
        <div className="section-head reveal">
          <div>
            <div className="mono" style={{ marginBottom: 14 }}>— 07 / Certifications</div>
            <h2>Learning <span className="it">milestones.</span></h2>
          </div>
          <p>Certifications demonstrating depth across cloud, AI, and software engineering domains.</p>
        </div>
        <div className="cert-grid reveal">
          {certs.map((c, i) => (
            <div key={i} className={`cert-card${i > 0 ? ` reveal reveal-delay-${i}` : ''}`}>
              <div className="cert-icon">{c.icon}</div>
              <h4>{c.title}</h4>
              <p>{c.sub}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
