import { useEffect, useRef } from 'react'
import '../styles/about.css'
import useReveal from '../hooks/useReveal'

export default function About() {
  useReveal()
  const canvasRef = useRef(null)

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    const ctx = canvas.getContext('2d')
    let w, h, animId
    const layers = [4, 6, 8, 6, 4, 2]
    let neurons = [], signals = []

    function resize() {
      const rect = canvas.parentElement.getBoundingClientRect()
      w = canvas.width = rect.width * window.devicePixelRatio
      h = canvas.height = rect.height * window.devicePixelRatio
      ctx.scale(window.devicePixelRatio, window.devicePixelRatio)
      w = rect.width; h = rect.height
    }

    function initNeurons() {
      neurons = []
      const layerSpacing = w / (layers.length + 1)
      layers.forEach((count, li) => {
        const x = layerSpacing * (li + 1)
        const neuronSpacing = h / (count + 1)
        for (let ni = 0; ni < count; ni++) {
          neurons.push({ x, y: neuronSpacing * (ni + 1), layer: li, radius: 3 + Math.random() * 2, alpha: 0.3 + Math.random() * 0.3, pulse: Math.random() * Math.PI * 2 })
        }
      })
    }

    function createSignal() {
      const fromLayer = Math.floor(Math.random() * (layers.length - 1))
      const from = neurons.filter(n => n.layer === fromLayer)
      const to = neurons.filter(n => n.layer === fromLayer + 1)
      if (!from.length || !to.length) return null
      const f = from[Math.floor(Math.random() * from.length)], t = to[Math.floor(Math.random() * to.length)]
      return { fromX: f.x, fromY: f.y, toX: t.x, toY: t.y, progress: 0, speed: 0.008 + Math.random() * 0.012, color: Math.random() > 0.5 ? [232,201,139] : [122,162,255] }
    }

    function draw() {
      ctx.clearRect(0, 0, w, h)
      ctx.strokeStyle = 'rgba(255,255,255,0.02)'; ctx.lineWidth = 0.5
      for (let x = 0; x < w; x += 30) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, h); ctx.stroke() }
      for (let y = 0; y < h; y += 30) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke() }
      for (let li = 0; li < layers.length - 1; li++) {
        const from = neurons.filter(n => n.layer === li), to = neurons.filter(n => n.layer === li + 1)
        from.forEach(f => { to.forEach(t => { ctx.strokeStyle = 'rgba(122,162,255,0.04)'; ctx.lineWidth = 0.5; ctx.beginPath(); ctx.moveTo(f.x, f.y); ctx.lineTo(t.x, t.y); ctx.stroke() }) })
      }
      if (Math.random() < 0.06) { const s = createSignal(); if (s) signals.push(s) }
      signals = signals.filter(s => s.progress <= 1)
      signals.forEach(s => {
        s.progress += s.speed
        const x = s.fromX + (s.toX - s.fromX) * s.progress, y = s.fromY + (s.toY - s.fromY) * s.progress
        const a = Math.sin(s.progress * Math.PI) * 0.8
        ctx.beginPath(); ctx.arc(x, y, 2.5, 0, Math.PI * 2); ctx.fillStyle = `rgba(${s.color.join(',')},${a})`; ctx.fill()
        ctx.beginPath(); ctx.arc(x, y, 6, 0, Math.PI * 2); ctx.fillStyle = `rgba(${s.color.join(',')},${a * 0.3})`; ctx.fill()
      })
      const time = Date.now() * 0.001
      neurons.forEach(n => {
        const pa = n.alpha + Math.sin(time + n.pulse) * 0.15
        ctx.beginPath(); ctx.arc(n.x, n.y, n.radius, 0, Math.PI * 2); ctx.fillStyle = `rgba(232,201,139,${pa})`; ctx.fill()
        ctx.beginPath(); ctx.arc(n.x, n.y, n.radius + 4, 0, Math.PI * 2); ctx.strokeStyle = `rgba(232,201,139,${pa * 0.2})`; ctx.lineWidth = 0.5; ctx.stroke()
      })
      animId = requestAnimationFrame(draw)
    }

    resize(); initNeurons(); draw()
    const onResize = () => { resize(); initNeurons() }
    window.addEventListener('resize', onResize)
    return () => { cancelAnimationFrame(animId); window.removeEventListener('resize', onResize) }
  }, [])

  const focus = ['Full Stack Development', 'AI Engineering', 'Cloud Technologies', 'Data Engineering', 'System Design']
  const stats = [
    { num: '15+', lbl: 'Projects Built' },
    { num: '100+', lbl: 'LeetCode Problems' },
    { num: '10+', lbl: 'Technologies Used' },
    { num: 'Multiple', lbl: 'AI & Cloud Projects' }
  ]

  return (
    <section id="about" style={{ background: 'linear-gradient(180deg,#07080b 0%,#0a0c12 100%)' }}>
      <div className="container about">
        <div className="about-text reveal">
          <div className="mono" style={{ marginBottom: 18 }}>— 02 / About</div>
          <h2>Engineering products with <span className="it">curiosity,</span> scalability and impact.</h2>
          <p>I am Sambhav Shah, a Computer Engineering student passionate about building scalable web applications, intelligent systems and modern software solutions.</p>
          <p>My interests span Full Stack Development, Artificial Intelligence, Cloud Computing, Data Engineering and System Design. I enjoy transforming complex problems into practical software products while continuously learning modern technologies and engineering best practices.</p>
          <div className="about-focus">
            <h4>Current Focus</h4>
            <div className="focus-tags">
              {focus.map(f => <span key={f} className="focus-tag">{f}</span>)}
            </div>
          </div>
          <div className="about-stats">
            {stats.map((s, i) => (
              <div key={i} className="stat">
                <div className="num">{s.num}</div>
                <div className="lbl" style={s.num === 'Multiple' ? { fontSize: '.6rem' } : {}}>{s.lbl}</div>
              </div>
            ))}
          </div>
        </div>
        <div className="about-visual reveal reveal-delay-1">
          <div className="about-visual-inner">
            <canvas ref={canvasRef} width="600" height="750"></canvas>
          </div>
          <div className="vbadge"><span className="l">Currently building</span><span>Full Stack + AI · 2026</span></div>
        </div>
      </div>
    </section>
  )
}
